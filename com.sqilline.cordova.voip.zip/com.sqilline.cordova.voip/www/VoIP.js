module.exports = {


  registerClient: function(successCallback,errorCallback) {

    cordova.exec(successCallback,
                 errorCallback,
                 "VoIP",
                 "registerSinch",
                 []);

  }

  stopClient: function(successCallback,errorCallback) {

    cordova.exec(successCallback,
                 errorCallback,
                 "VoIP",
                 "stopSinch",
                 []);

  }
};

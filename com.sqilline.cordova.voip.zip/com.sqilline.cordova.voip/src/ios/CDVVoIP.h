#import <Cordova/CDV.h>
#import <Sinch/Sinch.h>

@interface CDVVoIP : CDVPlugin <SINClientDelegate> {}

@property (strong, nonatomic) id<SINClient> client;



@property (nonatomic, readwrite, strong) id<SINCall> call;


- (void)registerSinch:(CDVInvokedUrlCommand*)command;

-(void)stopSinch:(CDVInvokedUrlCommand*)command;


@end


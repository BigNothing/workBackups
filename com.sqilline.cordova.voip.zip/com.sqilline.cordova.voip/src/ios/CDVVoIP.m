#import "CDVVoIP.h"


@interface CDVVoIP () <SINCallDelegate>
@end


@implementation CDVVoIP
- (void)pluginInitialize
{
}

- (void)registerSinch:(CDVInvokedUrlCommand*)command
{
    CDVPluginResult* pluginResult = nil;

if (!_client) {

    _client = [Sinch clientWithApplicationKey:@"2bd1c61e-b210-46db-86d7-b6441c84281b"
                            applicationSecret:@"UZzt3EnAgk2A8zlbTvDGfA=="
                              environmentHost:@"sandbox.sinch.com"
                                       userId:@"pesho"];

    _client.delegate = self;

    [_client setSupportCalling:YES];

    [_client start];
  
        pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK ];
    } else {
        pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_ERROR];
    }

    [self.commandDelegate sendPluginResult:pluginResult callbackId:command.callbackId];
}

-(void)stopSinch:(CDVInvokedUrlCommand*)command{


    if(_client != nil){

        [_client terminate]; 
        _client = nil;

         pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK ];

        } else {
            pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_ERROR];
        }

        [self.commandDelegate sendPluginResult:pluginResult callbackId:command.callbackId];
    }

}


-(void)createRoom:(CDVInvokedUrlCommand*)command{

    id<SINCallClient> callClient = [sinchClient callClient];
    id<SINCall> call = [callClient callConferenceWithId:@"trainingRoom"];

    call.delegate = self;


}


#pragma mark - SINClientDelegate

- (void)clientDidStart:(id<SINClient>)client {
  NSLog(@"Sinch client started successfully (version: %@)", [Sinch version]);
}

- (void)clientDidFail:(id<SINClient>)client error:(NSError *)error {
  NSLog(@"Sinch client error: %@", [error localizedDescription]);
}

- (void)client:(id<SINClient>)client
    logMessage:(NSString *)message
          area:(NSString *)area
      severity:(SINLogSeverity)severity
     timestamp:(NSDate *)timestamp {
  if (severity == SINLogSeverityCritical) {
    NSLog(@"%@", message);
  }
}



#pragma mark - SINCallDelegate

- (void)callDidProgress:(id<SINCall>)call {
  
  NSLog(@"call progress ");
}

- (void)callDidEstablish:(id<SINCall>)call {


  NSLog(@"call established ");
}

- (void)callDidEnd:(id<SINCall>)call {



  NSLog(@"call ended ");


}













@end












